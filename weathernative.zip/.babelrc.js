module.exports = {
    presets: [
        require("@babel/preset-env")
    ]
};