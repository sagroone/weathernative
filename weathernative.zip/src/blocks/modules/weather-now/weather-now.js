const weatherNowBlock = document.querySelector('.weather-now')

function showCurrentWeather( props ) {
    const weatherNowBlock = document.querySelector('.weather-now');
    weatherNowBlock.innerHTML = renderIco( props.weather[0].icon ) + renderCurrentWeather( props );
    setTimeout(() => {
        weatherNowBlock.classList.add('show');
    }, 400)
}

function renderIco( props ) {
    return `
        <div class="weather-now__ico">
        <object type="image/svg+xml" data="./img/svg/${props}.svg"></object>
        </div>
    `;
}

function renderCurrentWeather( props ) {

    const temp = Math.floor(props.main.temp);
    const description = props.weather[0].description.slice(0,1).toUpperCase() + props.weather[0].description.slice(1);

    return `
        <div class="weather-now__info">
            <div class="whole-day">
                <div class="whole-day__min">Min +16 <span class="cel">C</span></div>
                <div class="whole-day__max">Max +20 <span class="cel">C</span></div>
            </div>
            <div class="current-deg">
                <span class="current-deg__num">${addPlus(temp)}</span>
                <span class="current-deg__units cel active">C</span>
                <span class="current-deg__units far">F</span>
            </div>
            <div class="weather-conditions">${description}</div>
        </div>
    `;
}

function addPlus(num) {
    return ( num > 0 ) ? '+' + num : num;
}

export default showCurrentWeather;